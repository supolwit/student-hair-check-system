# Student Hair Check System

Insert full code from canvas into the respective files.